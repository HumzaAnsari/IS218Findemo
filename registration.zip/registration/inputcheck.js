function InputCheck(){ 
 	var usern = document.getElementById("Username").value; 
	var email = document.getElementById("Email").value; 
	var passw = document.getElementById("Password").value;
	var fname = document.getElementById("FirstName").value; 
	var lname = document.getElementById("LastName").value;
	
}

function NumberCheck(InputString, OutputString){
	for (var i = 0; i < InputString.length; i++) {
		if(InputString.charAt(i) >= '0' && InputString.charAt(i) <= '9'){
			document.getElementById(OutputString).innerHTML= "Cannot contain numbers.";
			return false;
		}
	}
	return true;
}

function EmailChecker(InputString, OutputString){
	var hasAt = false;
	for (var i = 0; i < InputString.length; i++) {
		if(InputString.charAt(i) == "@"){
			hasAt = true;
		}
		if(hasAt && InputString.charAt(i) == "."){
			return true;
		}
	}
	document.getElementById(OutputString).innerHTML= "Invaild email address.";
	return false;
}

function NoneChecker(InputString, OutputString){
	if (InputString.length){
		return true;
	} else {
		document.getElementById(OutputString).innerHTML= "Input required.";
		return false;
	}
}