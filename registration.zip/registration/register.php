<?php include("server.php") ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Sign up</title>
		<link rel = "stylesheet" href="style.css" type="text/css">
	</head>
	<body>
	
	<script src="inputcheck.js"><script>
	
	<div class="header">
		<h2>Sign Up</h2>
	</div>	
		
		<div class="container">
			<form method="post" action="register.php">
			<?php include("errors.php"); ?>
			<div class="InputGroup">
				<lable>Username: <br></lable>
				<input type="text" id="Username">
				<p> id="ErrorOne"&nbsp </p>
			</div>
			<div class="InputGroup">
				<lable>Email: <br></lable>
				<input type="text" id="Email">
				<p id="ErrorTwo">&nbsp; </p>
			</div>
			<div class="InputGroup">
				<lable>Password: <br></lable>
				<input type="text" id="Password">
				<p id="ErrorThree">&nbsp; </p>
			</div>
			<div class="InputGroup">
				<lable>First name: <br></lable>
				<input type="text" id="FirstName">
				<p id="ErrorFour">&nbsp; </p>
			</div>
			<div class="InputGroup">
				<lable>Last name: <br></lable>
				<input type="text" id="LastName">
				<p id="ErrorFive">&nbsp; </p>
			</div>
			<button type="button" value="button" onclick = "InputCheck()" class="btn">Submit</button>
			<button type="reset" value="Reset" class="btn">Reset</button>
			</form>
		</div>
	</body>	
</html>